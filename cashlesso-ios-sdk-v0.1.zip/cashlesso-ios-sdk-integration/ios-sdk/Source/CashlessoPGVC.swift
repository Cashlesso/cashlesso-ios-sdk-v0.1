//
//  CashlessoPG.swift
//  CashlessoSDK
//
//  Created by Jai Mataji on 15/04/20.
//

import Foundation
import WebKit


public class CashlessoPGVC: UIViewController{
    
    public weak var delegate: CashlessoPGDelegate?
    fileprivate var titleString: String! = "PAYMENT"
    fileprivate var titleColor: UIColor! = .black
    fileprivate var navigationBarColor: UIColor? = .white
    
    fileprivate var isUAT:Bool! = false
    
    fileprivate var PG_URL:String{
        get {
            if isUAT{
                return "https://uat.cashlesso.com/pgui/jsp/paymentrequest?"
            }
            else{
                return "https://www.cashlesso.com/pgui/jsp/paymentrequest?"
//                return "https://uat.cashlesso.com/pgui/jsp/paymentrequest?"
            }
        }
    }
    
    fileprivate var SECRET_KEY:String? = ""
    fileprivate var PARAMS:[String:Any]? = nil
    fileprivate var request: URLRequest!
    fileprivate var navBarTitle: UILabel!
    
    lazy var webView: WKWebView = {
        var PGWebView = WKWebView()
        PGWebView.frame = UIScreen.main.bounds
        PGWebView.navigationDelegate = self
        return PGWebView;
    }()
    
    public convenience init(params: [String:Any], secretKey:String,
                            titleString: String, titleColor: UIColor,
                            navigationBarColor: UIColor,isUAT:Bool) {
        self.init()
        //set it true while testing and set false while giving to merchant
        isDebugingOn = false
        
        SECRET_KEY = secretKey
        PARAMS = params
        
        self.titleString = titleString
        self.titleColor = titleColor
        self.navigationBarColor = navigationBarColor
        self.isUAT = isUAT
        
        AppUtility.secret = SECRET_KEY!
        
        //converting dictionary to string, that will be further used for creating hash/sending as request
        var dataStr = AppUtility.getPostString(params: params)
        
        //create hash and append to the above string
        dataStr.append(AppUtility.createHashAndAppend(reqStr: dataStr))
        webView.navigationDelegate = self
        webView.scrollView.isScrollEnabled = true
        
        log(namespace: "REQ_URL", message: "\(PG_URL)\(dataStr)")
        
        let urlString = "\(PG_URL)\(dataStr)".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        
        let pgRequestUrl = URL(string: urlString )!
        
        self.request = URLRequest(url: pgRequestUrl)
        self.request.httpMethod = "POST"
    }
    
    deinit {
        webView.stopLoading()
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        webView.uiDelegate = nil;
        webView.navigationDelegate = nil;
    }
    
    func loadRequest(_ request: URLRequest) {
        webView.load(request)
        webView.allowsBackForwardNavigationGestures = false
    }
    
    // MARK: - View Lifecycle
    
    override public func loadView() {
        view = webView
        loadRequest(request)
        self.navigationItem.setHidesBackButton(true, animated:true)
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override public func viewWillAppear(_ animated: Bool) {
        assert(self.navigationController != nil, "CashlessoPGVC needs to be contained in a UINavigationController.")
        super.viewWillAppear(true)
        setupNavigationTitle()
        
        //"UIUserInterfaceIdiom": The interface type for the device or an object that has a trait environment, such as a view and view controller.
        
        
        self.navigationController?.setToolbarHidden(true, animated: true)
        
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        if (UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.phone) {
            self.navigationController?.setToolbarHidden(true, animated: true)
        }
    }
    
    override public func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        // "isNetworkActivityIndicatorVisible": A Boolean value that turns an indicator of network activity on or off.
        // Specify true if the app should show network activity and false if it should not. The default value is false. A spinning indicator in the status bar shows network activity. The app may explicitly hide or show this indicator.
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
    
    
    func processResponse(rawData: String){
        var responseDict = AppUtility.convertStringToDict(rawData: rawData)
        
        if !AppUtility.checkResonseHASH(responseData: responseDict){
            ////009 response signature did not match
            responseDict = ["RESPONSE_CODE":"009","RESPONSE_MESSAGE":"Response signature did not match"]
        }
        self.delegate?.postresponse(data: responseDict)
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    
    func setupNavigationTitle(){
        if titleString == ""{
            titleString = "PAYMENT"
        }
        navBarTitle = UILabel()
        navBarTitle.backgroundColor = UIColor.clear
        if presentingViewController == nil {
            if let titleAttributes = navigationController!.navigationBar.titleTextAttributes {
                navBarTitle.textColor = titleAttributes[.foregroundColor] as? UIColor
            }
        }
        else {
            navBarTitle.textColor = self.titleColor
        }
        navBarTitle.shadowOffset = CGSize(width: 0, height: 1);
        navBarTitle.font = UIFont(name: "System-Medium", size: 17.0)
        navBarTitle.textAlignment = .center
        navigationItem.titleView = navBarTitle
        
        navigationController?.navigationBar.barTintColor = navigationBarColor
        
        self.navBarTitle.text = titleString
        self.navBarTitle.sizeToFit()
    }
    
}


//MARK:- WKNavigationDelegate

extension CashlessoPGVC: WKNavigationDelegate {
    
    public func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        log(namespace: "ERROR", message: error.localizedDescription)
        let alert = UIAlertController(title: "Message", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            //            self.navigationController?.popViewController(animated: true)
        }))
        self.present(alert, animated: true)
    }
    
    public func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        log(namespace: "didStartProvisionalNavigation", message: "navigating to url \(String(describing: webView.url!))")
        
        self.delegate?.didPGStartLoading()
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    public func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        log(namespace: "didFinish", message: "did finish navigating to url \(String(describing: webView.url!))")
        
        //Delegate triggered that web page load with success
        self.delegate?.didPGFinishLoading(success: true)
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        webView.evaluateJavaScript("getResponse()", completionHandler: {(response, error) in
            if let response = response as? String{
                if response != ""{
                    self.processResponse(rawData: response)
                }
                //else{900}
            }
        })
    }
    
    public func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        log(namespace: "didFail", message: "did fail navigating to url \(String(describing: webView.url!))")
        
        //Delegate triggered that web page load with failure
        self.delegate?.didPGFinishLoading(success: false)
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
}
