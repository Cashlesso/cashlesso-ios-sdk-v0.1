//
//  ProtocolUtility.swift
//  CashlessoSDK
//
//  Created by Jai Mataji on 28/04/20.
//

import Foundation

public protocol CashlessoPGDelegate: class {
    func didPGStartLoading()
    func didPGFinishLoading(success: Bool)
    func postresponse(data: [String:Any])
}
