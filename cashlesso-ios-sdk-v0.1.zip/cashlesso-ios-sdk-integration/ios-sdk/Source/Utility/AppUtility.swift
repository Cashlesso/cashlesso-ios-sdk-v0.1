//
//  AppUtility.swift
//  CashlessoSDK
//
//  Created by Jai Mataji on 15/04/20.
//

import Foundation


class AppUtility
{
    static var secret = ""
    static func getPostString(params:[String:Any]) -> String
    {
        var data = [String]()
        let keys = params.keys.sorted()
        for(key) in keys
        {
            data.append(key + "=\(params[key] ?? "")")
        }
        return data.map { String($0) }.joined(separator: "&")
    }
    

    static func convertStringToDict(rawData:String)->[String:Any]{
        var dictData = [String:Any]()
        
        if !rawData.contains("~") || !rawData.contains("="){
            return dictData
        }
        
        for data in rawData.split(separator: "~"){
            let key = data.split(separator: "=")[0]
            let value = data.split(separator: "=")[1]
            dictData.updateValue(value, forKey: String(key))
        }
        return dictData
    }
    
    static func checkResonseHASH(responseData:[String:Any])->Bool{
        var responseString = ""
        var responseDict: [String:Any] = responseData
        var hashValue = ""
        
        if responseDict.keys.contains("HASH"){
            hashValue = String(responseDict["HASH"]! as! Substring)
            responseDict.removeValue(forKey: "HASH")
        }
        responseString = getPostString(params: responseDict)
        if hashValue == createHash(reqStr: responseString) {
            return true
        }
        return false
        
    }
    
    static func createHashAndAppend(reqStr:String)->String{
        return "&HASH=\(createHash(reqStr: reqStr))"
    }
    
    static func createHash(reqStr:String)->String{
        var dataStrForHash = reqStr
        dataStrForHash.append(secret)
        let hash = dataStrForHash.replacingOccurrences(of: "&", with: "~").sha256()
        return hash
    }
    
    
}
