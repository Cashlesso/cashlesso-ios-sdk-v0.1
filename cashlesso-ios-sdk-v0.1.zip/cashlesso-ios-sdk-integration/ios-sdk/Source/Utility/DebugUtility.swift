//
//  DebugUtility.swift
//  CashlessoSDK
//
//  Created by Jai Mataji on 20/04/20.
//


public var isDebugingOn = false

public func log(namespace:String, message:String){
    if isDebugingOn{
        print("=============================================")
        print(namespace+": "+message)
        print("=============================================")
    }
}
