//
//  ViewController.swift
//  CashlessoSDK
//
//  Created by lalanvivek1991 on 04/06/2020.
//  Copyright (c) 2020 lalanvivek1991. All rights reserved.
//

import UIKit
import CashlessoSDK
class ViewController: UIViewController,UITextFieldDelegate {
    
    var orderId = Int()
    
    @IBOutlet weak var orderIdLabel: UILabel!
    @IBOutlet weak var responseLabel: UILabel!
    @IBOutlet weak var price: UITextField!
    
    @IBAction func makePayment(_ sender: Any) {
        if price.text == "0" || price.text == ""{
            let alert = UIAlertController(title: "Error", message: "Price cannot be blank or zero", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                switch action.style{
                case .default:
                    print("default")
                    
                case .cancel:
                    print("cancel")
                    
                case .destructive:
                    print("destructive")
                    
                    
                @unknown default:
                    print("destructive")
                    
                }}))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            let priceVal = Int((price.text! as NSString).doubleValue * 100)
            let reqDict =
                
                ["AMOUNT" : "\(priceVal)",
                    "CURRENCY_CODE" : "356",
                    "CUST_CITY" : "Demo City",
                    "CUST_COUNTRY" : "Demo Country",
                    "CUST_EMAIL" : "demo@cashlesso.co.in",
                    "CUST_NAME" : "Demo Merchant",
                    "CUST_PHONE" : "1234567890",
                    "CUST_SHIP_CITY" : "Demo Ship City",
                    "CUST_SHIP_COUNTRY" : "Demo Ship Country",
                    "CUST_SHIP_EMAIL" : "demoship@cashlesso.com",
                    "CUST_SHIP_NAME" : "Demo Ship Customer",
                    "CUST_SHIP_PHONE" : "0123456789",
                    "CUST_SHIP_STATE" : "Demo Ship State",
                    "CUST_SHIP_STREET_ADDRESS1" : "Demo Ship Address1",
                    "CUST_SHIP_STREET_ADDRESS2" : "Demo Ship Address2",
                    "CUST_SHIP_ZIP" : "Demo Ship Zip Code",
                    "CUST_STATE" : "Demo State",
                    "CUST_STREET_ADDRESS1" : "Demo Address1",
                    "CUST_STREET_ADDRESS2" : "Demo Address2",
                    "CUST_ZIP" : "Demo Zip Code",
                    "ORDER_ID" : "SIGORD220\(orderId)",//111111111",
                    "PAY_ID" : "1024400208184235",
                    "PRODUCT_DESC" : "Demo Product",
                    "RETURN_URL" :  "https://uat.cashlesso.com/pgui/jsp/iosResponse.jsp"]
            
            var webVC: CashlessoPGVC!
            webVC = CashlessoPGVC(params: reqDict, secretKey: "cc774eaff4c54d2c", titleString: "Payment", titleColor: .black, navigationBarColor: .yellow, isUAT: true)
            webVC.delegate = self
            
            
            self.navigationController?.pushViewController(webVC, animated: true)
        }
    }
    //009 response signature did not match
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //            ["AMOUNT":"100", "CURRENCY_CODE":"356","ORDER_ID":"CASH1586892343442","PAY_ID":"1024400208184235","RETURN_URL":"https://uat.cashlesso.com/pgui/jsp/iosResponse.jsp"]
        
        //            ["AMOUNT":"100", "CURRENCY_CODE":"356","ORDER_ID":"CASH1586892343442","PAY_ID":"1024400208184235","RETURN_URL":"https://uat.cashlesso.com/pgui/jsp/iosResponse.jsp"]
        
    }
    override func viewWillAppear(_ animated: Bool) {
        orderId = Int(Int64.random(in: 1111111111...9999999999))
        
        orderIdLabel.text = "OderId: SIGORD220\(orderId)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

extension ViewController: CashlessoPGDelegate{
    func postresponse(data: [String : Any]) {
        print("response data:  \(data)")
        
        responseLabel.text = """
        Previous Order Response:
        
        ORDER_ID: \(data["ORDER_ID"] ?? "")
        RESPONSE_MESSAGE: \(data["RESPONSE_MESSAGE"] ?? "")
        RESPONSE_CODE: \(data["RESPONSE_CODE"] ?? "")
        RESPONSE_DATE_TIME: \(data["RESPONSE_DATE_TIME"] ?? "")
        STATUS: \(data["STATUS"] ?? "") 
        """
    }
    
    func didPGStartLoading() {
        print("client started")
    }
    
    func didPGFinishLoading(success: Bool) {
        print("client fnished")
    }
    
    
}

