# CashlessoSDK

[![CI Status](https://img.shields.io/travis/lalanvivek1991/CashlessoSDK.svg?style=flat)](https://travis-ci.org/lalanvivek1991/CashlessoSDK)
[![Version](https://img.shields.io/cocoapods/v/CashlessoSDK.svg?style=flat)](https://cocoapods.org/pods/CashlessoSDK)
[![License](https://img.shields.io/cocoapods/l/CashlessoSDK.svg?style=flat)](https://cocoapods.org/pods/CashlessoSDK)
[![Platform](https://img.shields.io/cocoapods/p/CashlessoSDK.svg?style=flat)](https://cocoapods.org/pods/CashlessoSDK)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

CashlessoSDK is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'CashlessoSDK'
```

## Author

lalanvivek1991, lalanvivek1991@gmail.com

## License

CashlessoSDK is available under the MIT license. See the LICENSE file for more info.
